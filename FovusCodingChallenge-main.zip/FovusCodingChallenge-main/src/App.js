import React from 'react';

// Components
import InputForm from './Pages/inputForm';

function App() {
  return (
    <div>
      <InputForm />
    </div>
  )
}

export default App