export const EMPTY_OBJECT = Object.freeze({});

export const EMPTY_FILE = Object.freeze(new File([], ""))

export const PRE_SIGNED_URL = 'PRE_SIGNED_URL';

export const PUT_TO_DYNAMO_DB_URL = 'URL';
